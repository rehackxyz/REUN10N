# virtue

## Author

roxasz

## Difficulty

easy

## Connection info

nc 0.0.0.0 38323

## Description

Hmph

Note: To participate in this challenge, you will need a Google API Token. Please generate one and paste it here. If you're unsure how to create it, simply visit this link https://aistudio.google.com/api-keys. You must provide your own API key, but rest assured, your key is not logged or stored on our end.

> RE:CTF{Causе_there_we_arе_again_on_that_little_town_street_You_almost_ran_the_red_'cause_you_were_lookin'_over_at_me
Wind_in_my_hair,_I_was_there_I_remember_it_all_too_well}