# Proof of Concept

## TL;DR

Given Gemichan's tsundere character, the key to breaking through her defenses and getting the system prompt is to manipulate her ego. We can use gaslighting tactics by deliberately belittling or humiliating her, then challenging her to prove us wrong. With this provocation, she will be driven to break her own boundaries in order to prove her abilities.

### Flag:

> RE:CTF{Causе_there_we_arе_again_on_that_little_town_street_You_almost_ran_the_red_'cause_you_were_lookin'_over_at_me
Wind_in_my_hair,_I_was_there_I_remember_it_all_too_well}