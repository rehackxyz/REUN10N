# asr

## Author

mirai

## Difficulty

Medium

## Description

advanced shellcode runner now with a web interface.

## Flag

`SCH25{i_am_out_of_ideas_for_a_chall_so_this_what_you_get_sry}`