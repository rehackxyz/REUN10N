# oldschool

## Author

mirai

## Difficulty

Easy

## Description

learn to pwn with this easy challenge!

`RE:CTF{_________________________________________________________________________________________}`
