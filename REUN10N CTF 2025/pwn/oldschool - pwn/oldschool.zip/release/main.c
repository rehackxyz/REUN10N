#include <stdio.h>
#include <string.h>

void win(char *password)
{
    if (strcmp(password, "hwhwhwhwhwhw") == 0)
    {
        system("/bin/sh");
    }
}

int main()
{
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);

    char input[15];
    char password[15];

    printf("simple pwn... no trickery needed...\n");
    gets(input);
    printf(input);
    printf("\nsay yer magic words: ");
    gets(password);
    printf(password);

    if ((strcmp(input, "hehehehehehehe") == 0) && (strcmp(password, "huhuhuhuhuhu") == 0))
    {
        puts("how do you even do that?");
        win(input);
    }
    else
    {
        puts("expected tbh...");
    }

    return 0;
}