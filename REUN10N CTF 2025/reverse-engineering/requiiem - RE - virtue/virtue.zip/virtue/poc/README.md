# Proof of Concept

## TL;DR

decompile program file and understand the simple mapping of the opcodes. create a disassembler, navigate through the junk codes and get the flag

you could also just do dynamic analysis and bruteforce your way because this program is somewhat vulnerable to ltrace

### Flag:

> RE:CTF{Above_all___remember_that_God_looks_for_solid_virtues_in_us___such_as_patience___humility___obedience___abnegation_of_your_own_will_-_that_is___the_good_will_to_serve_Him_and_our_neighbor_in_Him____His_providence_allows_us_other_devotions_only_insofar_as_He_sees_that_they_are_useful_to_us___requiiem_wuzz_here}