import re
import sys

OPCODES = {
  "MOV": 0x01, "ADD": 0x02, "XOR": 0x03, "CMP": 0x04,
  "JMP": 0x05, "JNE": 0x06, "PRINT": 0x07, "INPUT": 0x08, "HALT": 0xFF,
}
REGS = {f"R{i}": i for i in range(256)}

def parse_imm(x):
  if x.startswith("'") and x.endswith("'"):
    s = x[1:-1]
    if s.startswith("\\"):
      return ord({"n": "\n", "t": "\t", "r": "\r", "0": "\0", "'": "'", '"': '"', "\\": "\\"}[s[1]])
    return ord(s)
  return int(x, 0)

def parse_reg(x): return REGS[x.strip(",")]

def assemble(lines):
  code, labels, pc = [], {}, 0
  # Pass 1: Calculate addresses
  for l in lines:
    l = l.split(";")[0].strip()
    if not l: continue
    if l.endswith(":"): labels[l[:-1]] = pc; continue
    op = l.split()[0].upper()
    if op in ("MOV", "CMP", "ADD", "XOR", "JMP", "JNE"): pc += 3
    elif op in ("PRINT", "INPUT"): pc += 2
    elif op == "HALT": pc += 1

  for l in lines:
    l = l.split(";")[0].strip()
    if not l or l.endswith(":"): continue
    p = re.findall(r"'[^']*'|\S+", l)
    op, a = p[0].upper(), p[1:]
    if op == "MOV": code += [OPCODES[op], parse_reg(a[0]), parse_imm(a[1])]
    elif op in ("ADD", "XOR"): code += [OPCODES[op], parse_reg(a[0]), parse_reg(a[1])]
    elif op == "CMP": code += [OPCODES[op], parse_reg(a[0]), parse_imm(a[1])]
    elif op in ("JMP", "JNE"):
      if a[0] in labels:
        addr = labels[a[0]]
      else:
        addr = parse_imm(a[0])
      code += [OPCODES[op], addr & 0xFF, (addr >> 8) & 0xFF]
    elif op in ("PRINT", "INPUT"): code += [OPCODES[op], parse_reg(a[0])]
    elif op == "HALT": code += [OPCODES[op]]
  return bytes(code)

if __name__ == "__main__":
  if len(sys.argv) < 3:
    print("Usage: python comp.py <input.asm> <output.bin>")
    sys.exit(1)
  asm = open(sys.argv[1]).readlines()
  open(sys.argv[2], "wb").write(assemble(asm))