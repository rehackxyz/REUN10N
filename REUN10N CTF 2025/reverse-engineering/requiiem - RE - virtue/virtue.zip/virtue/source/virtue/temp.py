import random
import sys
import uuid

# FLAG = "Above all, remember that God looks for solid virtues in us, such as patience, humility, obedience, abnegation of your own will - that is, the good will to serve Him and our neighbor in Him. His providence allows us other devotions only insofar as He sees that they are useful to us."
FLAG = "RE:CTF{Above_all___remember_that_God_looks_for_solid_virtues_in_us___such_as_patience___humility___obedience___abnegation_of_your_own_will_-_that_is___the_good_will_to_serve_Him_and_our_neighbor_in_Him____His_providence_allows_us_other_devotions_only_insofar_as_He_sees_that_they_are_useful_to_us___requiiem_wuzz_here}"
KEY = "Humility is the foundation of all the other virtues hence, in the soul in which this virtue does not exist there cannot be any other virtue except in mere appearance."

STATE_SIZE = 8
STATE_REG_START = 100
CALC_REGS = [f"R{i}" for i in range(1, 6)]
JUNK_REGS = [f"R{i}" for i in range(200, 250)]
JUNK_PROBABILITY = 1
MIN_JUNK_INSTRUCTIONS = 1
MAX_JUNK_INSTRUCTIONS = 3

def print_boilerplate():
  print("""
JMP main

fail:
  MOV R1, 'T'
  PRINT R1
  MOV R1, 'e'
  PRINT R1
  MOV R1, 't'
  PRINT R1
  MOV R1, '-'
  PRINT R1
  MOV R1, 't'
  PRINT R1
  MOV R1, 'o'
  PRINT R1
  MOV R1, 't'
  PRINT R1
  MOV R1, '!'
  PRINT R1
  HALT

success:
  MOV R1, 'y'
  PRINT R1
  MOV R1, 'e'
  PRINT R1
  MOV R1, 'p'
  PRINT R1
  MOV R1, 'p'
  PRINT R1
  MOV R1, 'p'
  PRINT R1
  MOV R1, 'p'
  PRINT R1
  MOV R1, 'p'
  PRINT R1
  MOV R1, 'p'
  PRINT R1
  MOV R1, 'p'
  PRINT R1
  MOV R1, 'p'
  PRINT R1
  MOV R1, 'p'
  PRINT R1
  MOV R1, 'p'
  PRINT R1
  MOV R1, 'p'
  PRINT R1
  HALT

main:
  MOV R1, 'E'
  PRINT R1
  MOV R1, 'n'
  PRINT R1
  MOV R1, 't'
  PRINT R1
  MOV R1, 'e'
  PRINT R1
  MOV R1, 'r'
  PRINT R1
  MOV R1, ' '
  PRINT R1
  MOV R1, 'f'
  PRINT R1
  MOV R1, 'l'
  PRINT R1
  MOV R1, 'a'
  PRINT R1
  MOV R1, 'g'
  PRINT R1
  MOV R1, ':'
  PRINT R1
  MOV R1, ' '
  PRINT R1
""")

def generate_junk_code():
  if random.random() > JUNK_PROBABILITY:
    return []
  junk_asm = []
  num_instructions = random.randint(MIN_JUNK_INSTRUCTIONS, MAX_JUNK_INSTRUCTIONS)
  for _ in range(num_instructions):
    op = random.choice(["MOV", "ADD", "XOR"])
    r1 = random.choice(JUNK_REGS)
    if op == "MOV":
      imm = random.randint(0, 255)
      junk_asm.append(f"  {op} {r1}, {hex(imm)}")
    else:
      r2 = random.choice(JUNK_REGS)
      junk_asm.append(f"  {op} {r1}, {r2}")
  return junk_asm

def obfuscated_mov(reg, value):
  asm = []
  val = value & 0xFF
  start_val = random.randint(0, 255)
  asm.append(f"  MOV {reg}, {hex(start_val)}")
  if random.choice([True, False]):
    diff = (val - start_val) & 0xFF
    temp_reg = random.choice(CALC_REGS)
    while temp_reg == reg:
       temp_reg = random.choice(CALC_REGS)
    asm.append(f"  MOV {temp_reg}, {hex(diff)}")
    asm.append(f"  ADD {reg}, {temp_reg}")
  else:
    diff = (val ^ start_val) & 0xFF
    temp_reg = random.choice(CALC_REGS)
    while temp_reg == reg:
       temp_reg = random.choice(CALC_REGS)
    asm.append(f"  MOV {temp_reg}, {hex(diff)}")
    asm.append(f"  XOR {reg}, {temp_reg}")
  return asm

def generate_nightmare_asm():
  print_boilerplate()
  state_regs = [f"R{STATE_REG_START + i}" for i in range(STATE_SIZE)]
  current_state = [random.randint(0, 255) for _ in range(STATE_SIZE)]
  
  print("\n; --- Initializing state vector ---")
  for reg, val in zip(state_regs, current_state):
    print(f"  MOV {reg}, {hex(val)}")
    for line in generate_junk_code():
      print(line)
    
  code_blocks = []
  
  for i, flag_char in enumerate(FLAG):
    flag_ord = ord(flag_char)
    key_ord = ord(KEY[i % len(KEY)])
    block_label = f"check_block_{i}_{uuid.uuid4().hex[:8]}"
    next_label_key = f"block_{i+1}"
    if i == len(FLAG) - 1:
      next_label_key = "success"
      
    block_asm = []
    input_reg = "R0"
    block_asm.extend([f"; --- Check for character {i} ('{flag_char}') ---", f"{block_label}:", f"  INPUT {input_reg}"])
    block_asm.extend(generate_junk_code())
    
    v1 = (current_state[i % STATE_SIZE] + key_ord) & 0xFF
    v2 = (current_state[(i + 3) % STATE_SIZE] ^ flag_ord) & 0xFF
    expected = ((v1 ^ v2) + current_state[(i * 2) % STATE_SIZE]) & 0xFF
    
    calc_reg1, calc_reg2, calc_reg3 = random.sample(CALC_REGS, 3)
    block_asm.extend(obfuscated_mov(calc_reg1, 0))
    block_asm.extend([
      f"  ADD {calc_reg1}, {state_regs[i % STATE_SIZE]}",
      f"  MOV {calc_reg2}, {hex(key_ord)}",
      f"  ADD {calc_reg1}, {calc_reg2}",
    ])
    block_asm.extend(generate_junk_code())
    block_asm.extend([
      f"  XOR {calc_reg2}, {calc_reg2}",
      f"  ADD {calc_reg2}, {state_regs[(i + 3) % STATE_SIZE]}",
      f"  XOR {calc_reg2}, {input_reg}",
      f"  XOR {calc_reg1}, {calc_reg2}",
      f"  ADD {calc_reg1}, {state_regs[(i * 2) % STATE_SIZE]}",
      f"  CMP {calc_reg1}, {hex(expected)}",
      f"  JNE fail"
    ])
    
    new_state = list(current_state)
    for j in range(STATE_SIZE):
      update_val = (flag_ord + key_ord + i + j) & 0xFF
      new_state[j] = (current_state[j] ^ update_val) & 0xFF
    current_state = new_state
    
    block_asm.append("; --- State update ---")
    for j in range(STATE_SIZE):
      update_val = (flag_ord + key_ord + i + j) & 0xFF
      temp_reg = random.choice([r for r in CALC_REGS if r != state_regs[j]])
      block_asm.extend(obfuscated_mov(temp_reg, update_val))
      block_asm.append(f"  XOR {state_regs[j]}, {temp_reg}")
      block_asm.extend(generate_junk_code())
      
    code_blocks.append({'key': f"block_{i}", 'label': block_label, 'asm': block_asm, 'next_label_key': next_label_key})
    
  label_map = {block['key']: block['label'] for block in code_blocks}
  label_map['success'] = 'success'
  print(f"  JMP {label_map['block_0']}")
  random.shuffle(code_blocks)

  print("\n; --- Shuffled and Obfuscated Check Blocks ---")
  for block in code_blocks:
    for line in block['asm']:
      print(line)
    print(f"  JMP {label_map[block['next_label_key']]}\n")

if __name__ == "__main__":
  generate_nightmare_asm()
