# Guidance

## Author

anarchistx

## Difficulty

Med

Server: http://5.223.57.169:5599
Spawner: http://5.223.57.169:5598
## Description

just another clientside challenge y'all, by the way, clair obscur: expedition 33 is goat.

Flag file in `/flag.txt`

`RE:HACK{IZIIIIIIIIIIIIIIIIIIIIIN_Cl4ir_0bsCur_3xp3d1t10n_33_w1ll_b3_th3_G4m3_0f_Th3_C3ntur13s_y4ll}`
