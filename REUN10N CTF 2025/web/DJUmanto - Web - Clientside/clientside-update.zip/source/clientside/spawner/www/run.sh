#!/bin/sh

if [ ! -e /var/run/docker.sock ]; then
    echo "[debug] docker daemon not found"
    exit 1
fi
echo "[debug] docker daemon found"
if [ -z "$IMAGE_NAME" ]; then
    echo "[debug] IMAGE_NAME not found"
    exit 1
fi
echo "[debug] IMAGE_NAME="$IMAGE_NAME""

echo "[debug] Building image "$IMAGE_NAME""
docker build --no-cache -t "$IMAGE_NAME" /bot

NODE_ENV=production node app.js
