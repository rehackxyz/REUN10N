sudo docker build -t clientside-builder ./client --no-cache &&
sudo docker create --name temp-artifact clientside-builder &&
sudo docker cp temp-artifact:/output/ ./ &&
sudo mv ./output ./spawner/bot/dist
sudo docker compose build --no-cache &&
sudo docker compose up -ds