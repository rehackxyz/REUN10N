# Hachuuu

## Author
anarchistx

## Difficulty
Easy

## Description
haiya been sneezin so hard

    RE:CTF{gr4ttzzz_y0u_l34rn3d_r4c3_c0nd1t10n_thr0ugh_f1l3_upl04d_anarchist_was_hereeee}