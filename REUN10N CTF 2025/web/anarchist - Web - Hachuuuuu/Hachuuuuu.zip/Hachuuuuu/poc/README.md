Make a solver script that interacts with the chall to understand the behaviour(file names after being uploaded)

then multithread uploading it and accessing it so that you have a chance to actually access the shell n run the command to get the flag

example look at the solver.py