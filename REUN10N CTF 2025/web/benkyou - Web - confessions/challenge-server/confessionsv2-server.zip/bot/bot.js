import { Client } from 'basic-ftp';
import { firefox } from 'playwright';
import { Readable } from 'stream';

const APP_URL = "http://web:3000";

export const setFlag = async () => {
    const client = new Client();
    client.ftp.verbose = true;
    try {
        await client.access({
            host: "db",
            user: "ftp",
            password: process.env.FTP_PASSWORD,
            port: 2121
        });
        const flagStream = Readable.from([process.env.FLAG || "RE:CTF{fakeflag}"]);
        await client.uploadFrom(flagStream, "flag.txt");
        console.log("Flag setup complete");
    } catch (err) {
        console.log(err);
    }
    client.close();
};

function sleep(s) {
    return new Promise((resolve) => setTimeout(resolve, s));
}

export const visit = async (url) => {
    const browser = await firefox.launch({
        headless: true,
        // executablePath: "/usr/bin/firefox", 
        args: [
            '--disable-dev-shm-usage',
            '--disable-gpu',
            '--no-gpu',
            '--disable-default-apps',
            '--disable-translate',
            '--disable-device-discovery-notifications',
            '--disable-software-rasterizer',
            '--disable-xss-auditor'
        ],
        ignoreHTTPSErrors: true
    });

    try {
        const page = await browser.newPage();

        await page.goto(`${APP_URL}/login`, { waitUntil: "domcontentloaded" });

        await page.evaluate(async ({ user, pass }) => {
            await fetch('/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    username: user,
                    password: pass
                }).toString()
            });
        }, { user: 'admin', pass: process.env.ADMIN_PASSWORD });

        await sleep(3000);
        
        console.log("Admin logged in.");

        await page.goto(url, {
            waitUntil: "load",
            timeout: 10 * 1000,
        });

        await sleep(15000);

        await page.close();

    } catch (e) {
        console.error("Bot error:", e);
    }

    await browser.close();

    console.log("Visit complete.");
};