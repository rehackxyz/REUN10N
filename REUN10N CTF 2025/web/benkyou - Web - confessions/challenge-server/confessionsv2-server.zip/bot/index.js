import express from "express";
import rateLimit from "express-rate-limit";
import { visit, setFlag } from "./bot.js";

const PORT = process.env.PORT || "1337";

const app = express();
app.use(express.urlencoded({ extended: true }));

app.use(express.static("public"));

setFlag();
let isBotVisiting = false;
const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 4,
  message: "Too many requests, please try again later.",
  standardHeaders: true,
  legacyHeaders: false,
});

app.use("/api", apiLimiter);

app.post("/api/report", async (req, res) => {
  const { url } = req.body;

  if (
    typeof url !== "string" ||
    (!url.startsWith("http://") && !url.startsWith("https://"))
  ) {
    return res.status(400).send("Invalid url");
  }

  if (isBotVisiting) {
    return res.status(429).send("Bot is busy visiting another URL. Please try again in 5 seconds.");
  }

  try {
    isBotVisiting = true;
    console.log(`[+] processing: ${url}`);
    
    await visit(url);
    
    return res.sendStatus(200);
  } catch (e) {
    console.error(`[-] Error visiting ${url}:`, e);
    return res.status(500).send("Something wrong");
  } finally {
    // Release the lock so the next request can process
    isBotVisiting = false;
  }
});

app.listen(PORT, () => {
    console.log(`Bot listening on http://0.0.0.0:${PORT}`);
});