const { Client } = require('basic-ftp');
const { randomBytes, randomUUID } = require('crypto');
const createDOMPurify = require('dompurify');
const express = require('express');
const session = require('express-session');
const { JSDOM } = require('jsdom');
const sqlite3 = require('sqlite3');
const { Writable, Readable } = require('stream');

const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(session({
    secret: randomBytes(16).toString('hex'),
    resave: false,
    saveUninitialized: true,
    cookie: { httpOnly: false }
}));

const db = new sqlite3.Database(':memory:');
db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL
        )`);
    db.run(`CREATE TABLE IF NOT EXISTS confessions (
        id TEXT PRIMARY KEY,
        user_id INTEGER NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id) 
        )`);
    db.run(`INSERT INTO users (username, password) VALUES ('admin', "${process.env.ADMIN_PASSWORD}")`);
})

async function handleFTP(task) {
    const client = new Client();
    client.ftp.verbose = true;
    try {
        await client.access({
            host: "db",
            user: "ftp",
            password: process.env.FTP_PASSWORD || "password123",
            port: '2121'
        });
        return await task(client);
    } catch (err) {
        console.log(err);
    }
    client.close();
}

async function downloadFromFTP(client, filename) {
    var chunks = [];
    const writable = new Writable({
        write(chunk, encoding, callback) {
            chunks.push(chunk);
            callback();
        }
    });
    await client.downloadTo(writable, filename);
    return Buffer.concat(chunks).toString('binary');
}

app.get('/login', (req, res) => {
    res.send(`
    <!DOCTYPE html>
    <html>
    <head>
        <title>Login | CTF Confessions</title>
        <style>
            body { background: #f7f8fa; font-family: 'Segoe UI', Arial, sans-serif; }
            .center-box {
                max-width: 400px; margin: 60px auto; background: #fff;
                border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.07);
                padding: 32px;
            }
            h1 { margin-top: 0; color: #2d3e50; }
            input[type="text"], input[type="password"] {
                width: 100%; padding: 10px; margin: 10px 0 20px 0;
                border: 1px solid #cfd8dc; border-radius: 6px; font-size: 1em;
            }
            button {
                background: #2d3e50; color: #fff; border: none; border-radius: 6px;
                padding: 10px 24px; font-size: 1em; cursor: pointer; width: 100%;
                transition: background 0.2s;
            }
            button:hover { background: #1a2533; }
            .link { display: block; text-align: center; margin-top: 18px; color: #2d3e50; text-decoration: none; }
        </style>
    </head>
    <body>
        <div class="center-box">
            <h1>Login</h1>
            <form method="POST" action="/login">
                <input name="username" type="text" placeholder="Username" required>
                <input name="password" type="password" placeholder="Password" required>
                <button type="submit">Login</button>
            </form>
            <a class="link" href="/register">Register here</a>
        </div>
    </body>
    </html>
    `);
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
        return res.send("Missing required values");
    }
    db.get("SELECT * FROM users WHERE username = ? AND password = ?", [username, password], (err, row) => {
        if (row) {
            req.session.userId = row.id;
            req.session.username = row.username;
            return res.redirect('/confessions');
        }
        return res.status(401).send('Invalid credentials');
    });
})

app.get('/register', (req, res) => {
    res.send(`
    <!DOCTYPE html>
    <html>
    <head>
        <title>Register | CTF Confessions</title>
        <style>
            body { background: #f7f8fa; font-family: 'Segoe UI', Arial, sans-serif; }
            .center-box {
                max-width: 400px; margin: 60px auto; background: #fff;
                border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.07);
                padding: 32px;
            }
            h1 { margin-top: 0; color: #2d3e50; }
            input[type="text"], input[type="password"] {
                width: 100%; padding: 10px; margin: 10px 0 20px 0;
                border: 1px solid #cfd8dc; border-radius: 6px; font-size: 1em;
            }
            button {
                background: #2d3e50; color: #fff; border: none; border-radius: 6px;
                padding: 10px 24px; font-size: 1em; cursor: pointer; width: 100%;
                transition: background 0.2s;
            }
            button:hover { background: #1a2533; }
            .link { display: block; text-align: center; margin-top: 18px; color: #2d3e50; text-decoration: none; }
        </style>
    </head>
    <body>
        <div class="center-box">
            <h1>Register</h1>
            <form method="POST" action="/register">
                <input name="username" type="text" placeholder="Username" required>
                <input name="password" type="password" placeholder="Password" required>
                <button type="submit">Register</button>
            </form>
            <a class="link" href="/login">Back to login</a>
        </div>
    </body>
    </html>
    `);
});

app.post('/register', (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
        return res.status(400).send('Missing required fields');
    }
    const sql = 'INSERT INTO users (username, password) VALUES (?, ?)';
    db.run(sql, [username, password], (err) => {
        if (err) {
            if (err.message.includes('UNIQUE constraint failed')) {
                return res.status(400).send('User already exists');
            }
            return res.status(500).send('Database error');
        }
        res.redirect('/login')
    });
});

app.post('/logout', (req, res) => {
    req.session.destroy(() => res.redirect('/login'));
});

function requireLogin(req, res, next) {
    if (!req.session.userId) {
        return res.redirect('/login');
    }
    next();
}

app.get('/confessions', requireLogin, async (req, res) => {
    db.all('SELECT id FROM confessions WHERE user_id = ?', [req.session.userId], (err, rows) => {
        let confessionsHtml = rows.map(row => `
            <div class="confession-card">
                <a href="/confession/${row.id}">${row.id}</a>
            </div>
        `).join('');

        if (rows.length == 0) {
            confessionsHtml = '<p class="empty">No confessions yet 👻.</p>';
        }

        const html = `
        <!DOCTYPE html>
        <html>
        <head>
            <title>CTF Confessions</title>
            <style>
                body {
                    font-family: 'Segoe UI', Arial, sans-serif;
                    background: #f7f8fa;
                    margin: 0;
                    padding: 0;
                }
                .navbar {
                    background: #2d3e50;
                    color: #fff;
                    padding: 16px 32px;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }
                .navbar a, .navbar form button {
                    color: #fff;
                    text-decoration: none;
                    margin-left: 16px;
                    background: none;
                    border: none;
                    font: inherit;
                    cursor: pointer;
                }
                .container {
                    max-width: 700px;
                    margin: 40px auto;
                    background: #fff;
                    border-radius: 12px;
                    box-shadow: 0 2px 12px rgba(0,0,0,0.07);
                    padding: 32px;
                }
                h1 {
                    margin-top: 0;
                    font-size: 2.2em;
                    color: #2d3e50;
                }
                form textarea {
                    width: 100%;
                    border-radius: 8px;
                    border: 1px solid #cfd8dc;
                    padding: 12px;
                    font-size: 1em;
                    resize: vertical;
                    min-height: 80px;
                    margin-bottom: 16px;
                }
                form button {
                    background: #2d3e50;
                    color: #fff;
                    border: none;
                    border-radius: 6px;
                    padding: 10px 24px;
                    font-size: 1em;
                    cursor: pointer;
                    transition: background 0.2s;
                }
                form button:hover {
                    background: #1a2533;
                }
                hr {
                    border: none;
                    border-top: 1px solid #e0e0e0;
                    margin: 32px 0 24px 0;
                }
                .confession-list {
                    display: flex;
                    flex-direction: column;
                    gap: 18px;
                }
                .confession-card {
                    background: #f1f5fb;
                    border-radius: 8px;
                    padding: 18px 20px;
                    box-shadow: 0 1px 4px rgba(44,62,80,0.04);
                    transition: box-shadow 0.2s;
                }
                .confession-card:hover {
                    box-shadow: 0 4px 16px rgba(44,62,80,0.09);
                }
                .confession-card a {
                    color: #2d3e50;
                    font-weight: 500;
                    text-decoration: none;
                    font-size: 1.1em;
                }
                .empty {
                    color: #888;
                    text-align: center;
                    margin: 32px 0;
                }
            </style>
        </head>
        <body>
            <div class="navbar">
                <div>Logged in as <b>${req.session.username}</b></div>
                <div>
                    <form action="/logout" method="POST" style="display:inline;">
                        <button type="submit">Logout</button>
                    </form>
                </div>
            </div>
            <div class="container">
                <h1>Write something here lol</h1>
                <form action="/save" method="POST">
                    <textarea name="content" placeholder="Insert kind comments here ☺️" required></textarea>
                    <button type="submit">Save</button>
                </form>
                <hr>
                <h2 style="margin-bottom:18px;">Your Confessions</h2>
                <div class="confession-list">
                    ${confessionsHtml}
                </div>
            </div>
        </body>
        </html>
    `;
        res.send(html);
    });
});

app.get('/confession/:id', async (req, res) => {
    const filename = req.params.id;
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(filename)) {
        return res.status(467).send("<h1>Naughty characters detected 🤓</h1>");
    }

    const content = await handleFTP(async (client) => {
        try {
            return await downloadFromFTP(client, filename);
        } catch (err) {
            console.log(err);
        }
    });
    if (!content) {
        return res.status(404).send(`<h1>404 - Document not found.</h1><a href="/confessions">Return to home</a>`);
    }

    const html = `
        <!DOCTYPE html>
        <html>
        <head>
            <title>View Confession</title>
            <style>
                body { background: #f7f8fa; font-family: 'Segoe UI', Arial, sans-serif; }
                .container {
                    max-width: 600px; margin: 40px auto; background: #fff;
                    border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.07);
                    padding: 32px;
                }
                .back-link {
                    color: #2d3e50; text-decoration: none; font-size: 1em;
                    margin-bottom: 18px; display: inline-block;
                }
                h1 { color: #2d3e50; font-size: 1.5em; margin-bottom: 18px; }
                .confession-content {
                    border: 1px solid #e0e0e0; border-radius: 8px;
                    padding: 24px; background: #f1f5fb; font-size: 1.1em;
                    margin-top: 12px; word-break: break-word;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <a class="back-link" href="/confessions">&larr; Return to home</a>
                <h1>${filename}</h1>
                <div class="confession-content">
                ${content}
                </div>
            </div>
        </body>
        </html>
    `;

    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.write(html);
    res.end();
});

app.post('/save', requireLogin, async (req, res) => {
    const content = req.body.content || '';

    const DOMPurify = createDOMPurify(new JSDOM('').window);
    const sanitized = DOMPurify.sanitize(content, { ALLOW_ARIA_ATTR: false, ALLOW_DATA_ATTR: false });

    let uuid = randomUUID();
    const filename = uuid;
    const sourceStream = Readable.from([sanitized]);
    await handleFTP(async (client) => {
        await client.uploadFrom(sourceStream, filename);
        console.log(`Uploaded ${filename}`);
    });
    db.run('INSERT INTO confessions (id, user_id) VALUES (?, ?)', [uuid, req.session.userId], (err) => {
        if (err) {
            return res.status(500).send('Database error');
        }
        res.redirect('/confessions');
    })
});

app.get('/', (req, res) => {
    res.redirect(301, '/confessions');
});

app.listen("3000", () => {
    console.log(`Server running at http://localhost:3000`);
});