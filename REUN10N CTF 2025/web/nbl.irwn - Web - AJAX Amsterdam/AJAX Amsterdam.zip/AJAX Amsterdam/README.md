## TITLE
AJAX Amsterdam

<br>

## DESCRIPTION:
F-Side is a Dutch football hooligan group and fanatical supporter base associated with the Amsterdam-based club AFC Ajax. So..

*Note: This is Wordpress's plugin CTF challenge.

<br>

## AUTHOR
`nblirwn`