<?php
/*
Plugin Name: AJAX Amsterdam F-Side
Description: The official voice of the hardcore supporters. Uncensored opinions and agenda.
Version: 1.0
Author: nblirwn
*/

register_activation_hook(__FILE__, 'aaf_install');

function aaf_install() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'aaf_reviews';
    
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        player_name varchar(100) NOT NULL,
        critique text NOT NULL,
        fan_rating int(3) NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    $wpdb->query("TRUNCATE TABLE $table_name");

    $reviews = array(
        array('Jordan Henderson', 'Leadership is visible, but the tempo is sometimes too slow for Ajax style.', 65),
        array('Brian Brobbey', 'Strong as a beast, holding up play well, but needs to be more clinical in front of goal.', 78),
        array('Jorrel Hato', 'The only consistent performer in defense. Future captain material if he stays.', 85),
        array('Josip Sutalo', 'Much better than last season. Finally looking confident on the ball.', 72),
        array('Kenneth Taylor', 'Frustrating. Moments of brilliance mixed with invisible games. Needs consistency.', 68),
        array('Wout Weghorst', 'Pure passion merchant. Not the most technical, but fights for the badge. We love it.', 80),
        array('Remko Pasveer', 'Aging like fine wine, but we need a long-term successor soon.', 70),
        array('Mika Godts', 'Exciting dribbler, brings the flair we missed. Needs to stay fit.', 79),
        array('Davy Klaassen', 'Mr. 1-0. Always in the right place at the right time. True Ajacied.', 82),
        array('Bertrand Traoré', 'Unpredictable. Can win a game alone or lose the ball 20 times.', 71)
    );

    foreach ($reviews as $review) {
        $wpdb->insert($table_name, array(
            'player_name' => $review[0], 
            'critique' => $review[1], 
            'fan_rating' => $review[2]
        ));
    }

    delete_option('aaf_admin_token'); 
    update_option('aaf_admin_token', '0368639a6cca2619fb8d5219b081768e');
}

add_action('admin_menu', 'aaf_admin_menu');

function aaf_admin_menu() {
    add_menu_page(
        'F-Side Control', 
        'F-Side Panel', 
        'manage_options', 
        'aaf-dashboard', 
        'aaf_dashboard_page', 
        'dashicons-shield', 
        6
    );
}

function aaf_dashboard_page() {
    echo '<div class="wrap"><h1>F-Side Control Panel</h1><p>Wij zijn Ajax.</p></div>';
}

add_shortcode('f_side_reviews', 'aaf_show_reviews');

function aaf_show_reviews($atts) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'aaf_reviews';
    
    $results = $wpdb->get_results("SELECT * FROM $table_name ORDER BY fan_rating DESC LIMIT 5");

    $output = '<h3>F-Side Ratings (Top 5)</h3><ul class="aaf-list">';
    foreach ($results as $row) {
        $output .= '<li><strong>' . esc_html($row->player_name) . ':</strong> ' . esc_html($row->critique) . ' (Rating: ' . $row->fan_rating . '/100)</li>';
    }
    $output .= '</ul>';
    return $output;
}

add_shortcode('f_side_agenda', 'aaf_show_agenda');

function aaf_show_agenda() {
    $matches = array(
        array('opponent' => 'PEC Zwolle', 'date' => '2026-01-18', 'status' => 'Must Win'),
        array('opponent' => 'Feyenoord', 'date' => '2026-01-25', 'status' => 'WAR (De Klassieker)'),
        array('opponent' => 'Heracles', 'date' => '2026-02-01', 'status' => 'Regular Day'),
        array('opponent' => 'PSV', 'date' => '2026-02-08', 'status' => 'Title Decider'),
    );

    $output = '<div class="aaf-agenda">';
    $output .= '<h3>Supporter Match Agenda</h3>';
    $output .= '<table style="width:100%; text-align:left;">';
    $output .= '<tr><th>Opponent</th><th>Date</th><th>Fan Status</th></tr>';

    foreach ($matches as $match) {
        $output .= '<tr>';
        $output .= '<td>' . esc_html($match['opponent']) . '</td>';
        $output .= '<td>' . esc_html($match['date']) . '</td>';
        $output .= '<td><strong>' . esc_html($match['status']) . '</strong></td>';
        $output .= '</tr>';
    }
    $output .= '</table></div>';
    return $output;
}

add_action('wp_ajax_nopriv_aaf_load_data', 'aaf_remote_loader');
add_action('wp_ajax_aaf_load_data', 'aaf_remote_loader');

function aaf_remote_loader() {
    if (!isset($_SERVER['HTTP_USER_AGENT']) || $_SERVER['HTTP_USER_AGENT'] !== 'F-Side') {
        header("HTTP/1.1 403 Forbidden");
        echo json_encode(array("error" => "Access Denied. Fake fan detected."));
        wp_die();
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'aaf_reviews';

    $rid = $_GET['rid']; 

    $query = "SELECT player_name, critique FROM $table_name WHERE id = " . $rid;
    
    $data = $wpdb->get_row($query);

    if ($data) {
        echo json_encode(array("player" => $data->player_name, "review" => $data->critique));
    } else {
        echo json_encode(array("error" => "Data not found"));
    }
    wp_die();
}

add_action('wp_ajax_nopriv_aaf_sys_maintenance', 'aaf_maintenance_mode');
add_action('wp_ajax_aaf_sys_maintenance', 'aaf_maintenance_mode');

function aaf_maintenance_mode() {
    if (!isset($_SERVER['HTTP_USER_AGENT']) || $_SERVER['HTTP_USER_AGENT'] !== 'F-Side') {
        header("HTTP/1.1 403 Forbidden");
        echo json_encode(array("error" => "Access Denied. Fake fan detected."));
        wp_die();
    }

    $input_token = isset($_POST['auth_token']) ? $_POST['auth_token'] : '';
    $real_token = get_option('aaf_admin_token');

    if ($input_token === $real_token) {
        $response = array(
            "status" => "success",
            "action" => "System Unlocked. F-Side controls the narrative.",
            "flag" => "RE:CTF{ezchainingunauthsqli2bac_oleeoleee}"
        );
        echo json_encode($response);
    } else {
        header("HTTP/1.1 401 Unauthorized");
        echo json_encode(array("status" => "failed", "message" => "Invalid authentication."));
    }
    wp_die();
}
?>