#!/bin/bash

echo "🧹 Stopping services..."
docker-compose down
echo "✅ Services stopped and containers removed"
